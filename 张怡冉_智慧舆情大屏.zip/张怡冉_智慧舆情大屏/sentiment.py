# 智慧舆情控制器
import tornado.web
import json
import random
from datetime import datetime, timedelta
from collections import Counter
import re
from app.controllers.base import BaseHandler
from app.models.db import get_connection

class SentimentDashboardHandler(BaseHandler):
    """数智大屏页面"""
    @tornado.web.authenticated
    def get(self):
        self.render("sentiment/dashboard.html", title="数智大屏")

class SentimentAnalysisHandler(BaseHandler):
    """智能舆情分析"""
    @tornado.web.authenticated
    def get(self):
        self.render("sentiment/analysis.html", title="智能舆情分析")

class SentimentApiHandler(BaseHandler):
    """舆情数据API"""
    @tornado.web.authenticated
    def get(self):
        action = self.get_argument("action", "")
        
        if action == "overview":
            # 获取概览数据
            data = self.get_overview_data()
            self.write({"code": 0, "data": data})
            
        elif action == "wordcloud":
            # 获取词云数据
            data = self.get_wordcloud_data()
            self.write({"code": 0, "data": data})
            
        elif action == "trend":
            # 获取趋势数据
            days = int(self.get_argument("days", 7))
            data = self.get_trend_data(days)
            self.write({"code": 0, "data": data})
            
        elif action == "geo":
            # 获取地理分布数据
            data = self.get_geo_data()
            self.write({"code": 0, "data": data})
            
        elif action == "sentiment":
            # 获取情感分析数据
            data = self.get_sentiment_data()
            self.write({"code": 0, "data": data})
            
        elif action == "hot_topics":
            # 获取热门话题
            data = self.get_hot_topics()
            self.write({"code": 0, "data": data})
            
        elif action == "alerts":
            # 获取预警信息
            data = self.get_alerts()
            self.write({"code": 0, "data": data})
            
        elif action == "chat_analysis":
            # 分析聊天数据
            data = self.analyze_chat_data()
            self.write({"code": 0, "data": data})
            
        elif action == "spy_analysis":
            # 分析瞭望数据
            data = self.analyze_spy_data()
            self.write({"code": 0, "data": data})
            
        else:
            self.write({"code": 1, "msg": "未知操作"})
    
    def get_overview_data(self):
        """获取概览数据"""
        with get_connection() as conn:
            # 统计各类数据
            stats = {}
            
            # 消息总数
            cursor = conn.execute("SELECT COUNT(*) as count FROM messages")
            stats['total_messages'] = cursor.fetchone()['count']
            
            # 今日消息
            cursor = conn.execute(
                "SELECT COUNT(*) as count FROM messages WHERE date(create_at) = date('now')"
            )
            stats['today_messages'] = cursor.fetchone()['count']
            
            # 用户数
            cursor = conn.execute("SELECT COUNT(*) as count FROM users")
            stats['total_users'] = cursor.fetchone()['count']
            
            # 活跃用户数（今日有发言）
            cursor = conn.execute(
                """SELECT COUNT(DISTINCT sender_id) as count 
                FROM messages WHERE date(create_at) = date('now')"""
            )
            stats['active_users'] = cursor.fetchone()['count']
            
            # 群聊数
            cursor = conn.execute("SELECT COUNT(*) as count FROM chat_groups WHERE status = 1")
            stats['total_groups'] = cursor.fetchone()['count']
            
            # 瞭望数据数
            cursor = conn.execute("SELECT COUNT(*) as count FROM spy_data")
            stats['total_spy_data'] = cursor.fetchone()['count']
            
            # 舆情预警数
            cursor = conn.execute(
                "SELECT COUNT(*) as count FROM sentiment_data WHERE sentiment_score < -0.5"
            )
            stats['alert_count'] = cursor.fetchone()['count']
            
            return stats
    
    def get_wordcloud_data(self):
        """获取词云数据"""
        with get_connection() as conn:
            # 从消息和瞭望数据中提取关键词
            cursor = conn.execute(
                "SELECT content FROM messages WHERE msg_type = 1 ORDER BY create_at DESC LIMIT 1000"
            )
            messages = [row['content'] for row in cursor.fetchall()]
            
            cursor = conn.execute(
                "SELECT title, summary FROM spy_data ORDER BY create_at DESC LIMIT 500"
            )
            spy_data = cursor.fetchall()
            
            # 合并文本
            all_text = ' '.join(messages)
            for item in spy_data:
                all_text += ' ' + (item['title'] or '') + ' ' + (item['summary'] or '')
            
            # 简单的中文分词（使用正则）
            words = re.findall(r'[\u4e00-\u9fa5]{2,8}', all_text)
            
            # 过滤停用词
            stop_words = {'我们', '你们', '他们', '它们', '这个', '那个', '这里', '那里', '今天', '明天', '现在', '可以', '没有', '什么', '怎么', '还是', '就是', '但是', '然后', '因为', '所以', '如果', '虽然', '需要', '已经', '进行', '通过', '作为', '使用', '根据', '关于', '目前', '表示', '认为', '成为', '开始', '结束', '完成', '实现', '发展', '工作', '问题', '情况', '时间', '地方', '时候', '一下', '一个', '一些', '这些', '那些', '这样', '那样', '非常', '真的', '比较', '可能', '应该', '不能', '不会', '不要', '不能', '不是', '不能', '不要'}
            
            filtered_words = [w for w in words if w not in stop_words and len(w) >= 2]
            
            # 统计词频
            word_counts = Counter(filtered_words)
            
            # 转换为词云格式
            wordcloud_data = [
                {"name": word, "value": count}
                for word, count in word_counts.most_common(100)
            ]
            
            return wordcloud_data
    
    def get_trend_data(self, days=7):
        """获取趋势数据"""
        with get_connection() as conn:
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days)
            
            dates = []
            message_counts = []
            spy_counts = []
            
            for i in range(days):
                date = start_date + timedelta(days=i)
                date_str = date.strftime('%Y-%m-%d')
                dates.append(date_str)
                
                # 消息数
                cursor = conn.execute(
                    "SELECT COUNT(*) as count FROM messages WHERE date(create_at) = ?",
                    (date_str,)
                )
                message_counts.append(cursor.fetchone()['count'])
                
                # 瞭望数据数
                cursor = conn.execute(
                    "SELECT COUNT(*) as count FROM spy_data WHERE date(create_at) = ?",
                    (date_str,)
                )
                spy_counts.append(cursor.fetchone()['count'])
            
            return {
                "dates": dates,
                "messages": message_counts,
                "spy_data": spy_counts
            }
    
    def get_geo_data(self):
        """获取地理分布数据（模拟）"""
        # 模拟全球分布数据
        geo_data = [
            {"name": "China", "value": random.randint(1000, 5000)},
            {"name": "United States", "value": random.randint(500, 2000)},
            {"name": "Japan", "value": random.randint(300, 1500)},
            {"name": "United Kingdom", "value": random.randint(200, 1000)},
            {"name": "Germany", "value": random.randint(200, 1000)},
            {"name": "France", "value": random.randint(150, 800)},
            {"name": "India", "value": random.randint(300, 1200)},
            {"name": "Brazil", "value": random.randint(100, 600)},
            {"name": "Russia", "value": random.randint(150, 700)},
            {"name": "Australia", "value": random.randint(100, 500)},
            {"name": "Canada", "value": random.randint(100, 500)},
            {"name": "South Korea", "value": random.randint(150, 600)},
            {"name": "Singapore", "value": random.randint(80, 400)},
            {"name": "Thailand", "value": random.randint(50, 300)},
            {"name": "Vietnam", "value": random.randint(50, 300)},
        ]
        return geo_data
    
    def get_sentiment_data(self):
        """获取情感分析数据"""
        with get_connection() as conn:
            # 获取已有的情感分析数据
            cursor = conn.execute(
                """SELECT sentiment_score, COUNT(*) as count 
                FROM sentiment_data 
                WHERE sentiment_score IS NOT NULL
                GROUP BY ROUND(sentiment_score, 1)"""
            )
            
            sentiment_dist = {"positive": 0, "neutral": 0, "negative": 0}
            
            for row in cursor.fetchall():
                score = row['sentiment_score']
                count = row['count']
                
                if score > 0.3:
                    sentiment_dist['positive'] += count
                elif score < -0.3:
                    sentiment_dist['negative'] += count
                else:
                    sentiment_dist['neutral'] += count
            
            # 如果没有数据，使用模拟数据
            if sum(sentiment_dist.values()) == 0:
                sentiment_dist = {
                    "positive": random.randint(40, 60),
                    "neutral": random.randint(20, 40),
                    "negative": random.randint(10, 30)
                }
            
            return sentiment_dist
    
    def get_hot_topics(self):
        """获取热门话题"""
        with get_connection() as conn:
            # 从消息中提取热门话题
            cursor = conn.execute(
                "SELECT content FROM messages WHERE msg_type = 1 ORDER BY create_at DESC LIMIT 500"
            )
            messages = [row['content'] for row in cursor.fetchall()]
            
            # 提取话题（带#的内容）
            topics = []
            for msg in messages:
                found = re.findall(r'#([^#]+)#', msg)
                topics.extend(found)
            
            if not topics:
                # 模拟热门话题
                topics = ['人工智能', '大数据', '云计算', '区块链', '物联网', '5G', '元宇宙', '新能源', '碳中和', '数字化转型']
            
            topic_counts = Counter(topics)
            
            hot_topics = [
                {"topic": topic, "heat": count * 10 + random.randint(50, 100)}
                for topic, count in topic_counts.most_common(20)
            ]
            
            return hot_topics
    
    def get_alerts(self):
        """获取舆情预警"""
        with get_connection() as conn:
            cursor = conn.execute(
                """SELECT * FROM sentiment_data 
                WHERE sentiment_score < -0.5 
                ORDER BY create_at DESC LIMIT 10"""
            )
            alerts = [dict(row) for row in cursor.fetchall()]
            
            # 如果没有数据，生成模拟预警
            if not alerts:
                alerts = [
                    {
                        "id": i,
                        "content": f"模拟预警内容 {i+1}",
                        "sentiment_score": round(random.uniform(-0.9, -0.5), 2),
                        "create_at": (datetime.now() - timedelta(hours=i*2)).strftime('%Y-%m-%d %H:%M:%S')
                    }
                    for i in range(5)
                ]
            
            return alerts
    
    def analyze_chat_data(self):
        """分析聊天数据"""
        with get_connection() as conn:
            # 获取最近的消息进行分析
            cursor = conn.execute(
                """SELECT m.*, u.username, u.nickname 
                FROM messages m
                JOIN users u ON m.sender_id = u.id
                WHERE m.msg_type = 1
                ORDER BY m.create_at DESC LIMIT 100"""
            )
            messages = [dict(row) for row in cursor.fetchall()]
            
            # 简单的情感分析
            positive_words = ['好', '棒', '优秀', '喜欢', '爱', '开心', '快乐', '感谢', '赞', '不错', '完美', '满意', '成功']
            negative_words = ['差', '糟', '讨厌', '恨', '难过', '失望', '垃圾', '烂', '失败', '问题', '错误', '不好', '不行']
            
            analysis = {
                "total_analyzed": len(messages),
                "positive_count": 0,
                "negative_count": 0,
                "neutral_count": 0,
                "keywords": [],
                "active_users": [],
                "summary": ""
            }
            
            all_text = ""
            user_message_count = {}
            
            for msg in messages:
                content = msg['content']
                all_text += content + " "
                
                # 统计用户活跃度
                user_id = msg['sender_id']
                user_name = msg['nickname'] or msg['username']
                if user_id not in user_message_count:
                    user_message_count[user_id] = {"name": user_name, "count": 0}
                user_message_count[user_id]["count"] += 1
                
                # 简单情感判断
                pos_count = sum(1 for w in positive_words if w in content)
                neg_count = sum(1 for w in negative_words if w in content)
                
                if pos_count > neg_count:
                    analysis["positive_count"] += 1
                elif neg_count > pos_count:
                    analysis["negative_count"] += 1
                else:
                    analysis["neutral_count"] += 1
            
            # 提取关键词
            words = re.findall(r'[\u4e00-\u9fa5]{2,6}', all_text)
            stop_words = {'我们', '你们', '这个', '那个', '可以', '没有', '什么'}
            filtered = [w for w in words if w not in stop_words]
            analysis["keywords"] = [w for w, c in Counter(filtered).most_common(10)]
            
            # 活跃用户
            analysis["active_users"] = sorted(
                user_message_count.values(), 
                key=lambda x: x["count"], 
                reverse=True
            )[:5]
            
            # 生成总结
            total = analysis["total_analyzed"]
            if total > 0:
                pos_rate = analysis["positive_count"] / total * 100
                if pos_rate > 60:
                    analysis["summary"] = f"近期聊天氛围积极正面，正面情绪占比{pos_rate:.1f}%"
                elif pos_rate < 30:
                    analysis["summary"] = f"近期聊天存在负面情绪，需要关注，负面情绪占比{(analysis['negative_count']/total*100):.1f}%"
                else:
                    analysis["summary"] = f"近期聊天情绪分布较为均衡"
            
            return analysis
    
    def analyze_spy_data(self):
        """分析瞭望数据"""
        with get_connection() as conn:
            cursor = conn.execute(
                """SELECT * FROM spy_data ORDER BY create_at DESC LIMIT 100"""
            )
            spy_data = [dict(row) for row in cursor.fetchall()]
            
            analysis = {
                "total_analyzed": len(spy_data),
                "source_distribution": {},
                "keyword_trends": [],
                "summary": ""
            }
            
            # 来源分布
            cursor = conn.execute(
                """SELECT ss.name, COUNT(*) as count 
                FROM spy_data sd
                JOIN spy_sources ss ON sd.source_id = ss.id
                GROUP BY sd.source_id"""
            )
            analysis["source_distribution"] = {row['name']: row['count'] for row in cursor.fetchall()}
            
            # 关键词趋势
            all_keywords = []
            for item in spy_data:
                if item['keyword']:
                    all_keywords.append(item['keyword'])
            
            keyword_counts = Counter(all_keywords)
            analysis["keyword_trends"] = [
                {"keyword": k, "count": c} 
                for k, c in keyword_counts.most_common(10)
            ]
            
            # 生成总结
            if spy_data:
                analysis["summary"] = f"共采集到{len(spy_data)}条数据，涉及{len(analysis['source_distribution'])}个数据源"
            
            return analysis
    
    @tornado.web.authenticated
    def post(self):
        """舆情分析操作"""
        action = self.get_argument("action", "")
        
        if action == "analyze_content":
            # 分析指定内容
            content = self.get_argument("content", "").strip()
            if not content:
                self.write({"code": 1, "msg": "内容不能为空"})
                return
            
            # 简单情感分析
            result = self.analyze_sentiment(content)
            self.write({"code": 0, "data": result})
            
        elif action == "save_analysis":
            # 保存分析结果
            source_type = self.get_argument("source_type", "")
            source_id = int(self.get_argument("source_id", 0))
            content = self.get_argument("content", "")
            sentiment_score = float(self.get_argument("sentiment_score", 0))
            keywords = self.get_argument("keywords", "[]")
            
            with get_connection() as conn:
                conn.execute(
                    """INSERT INTO sentiment_data 
                    (source_type, source_id, content, sentiment_score, keywords)
                    VALUES (?, ?, ?, ?, ?)""",
                    (source_type, source_id, content, sentiment_score, keywords)
                )
                conn.commit()
            
            self.write({"code": 0, "msg": "分析结果已保存"})
            
        else:
            self.write({"code": 1, "msg": "未知操作"})
    
    def analyze_sentiment(self, text):
        """简单的情感分析"""
        positive_words = ['好', '棒', '优秀', '喜欢', '爱', '开心', '快乐', '感谢', '赞', '不错', '完美', '满意', '成功', '幸福', '美好', '精彩', '厉害', '强', '牛', 'good', 'great', 'excellent', 'love', 'like', 'happy', 'thanks', 'best', 'awesome', 'perfect']
        negative_words = ['差', '糟', '讨厌', '恨', '难过', '失望', '垃圾', '烂', '失败', '问题', '错误', '不好', '不行', '坏', '惨', '痛苦', '烦', '气', '怒', 'bad', 'terrible', 'hate', 'sad', 'angry', 'worst', 'awful', 'wrong', 'error', 'fail']
        
        pos_count = sum(1 for w in positive_words if w in text.lower())
        neg_count = sum(1 for w in negative_words if w in text.lower())
        
        total = pos_count + neg_count
        if total == 0:
            score = 0
            sentiment = "neutral"
        else:
            score = (pos_count - neg_count) / total
            if score > 0.3:
                sentiment = "positive"
            elif score < -0.3:
                sentiment = "negative"
            else:
                sentiment = "neutral"
        
        # 提取关键词
        words = re.findall(r'[\u4e00-\u9fa5]{2,6}', text)
        stop_words = {'我们', '你们', '这个', '那个', '可以', '没有', '什么', '怎么', '还是', '就是'}
        keywords = [w for w in words if w not in stop_words][:10]
        
        return {
            "sentiment": sentiment,
            "score": round(score, 2),
            "keywords": keywords,
            "positive_count": pos_count,
            "negative_count": neg_count
        }
